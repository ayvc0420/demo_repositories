<template>
    <div>
        <div>BOM Data:</div>
        <div>{{ bomData }}</div>
        <div>CAD Data:</div>
        <div>{{ cadData }}</div>
    </div>
</template>


<style scope>
</style>


<script setup>

    import { useExcelStore } from '@/stores/excelStore'
    import { onMounted, ref, watch } from 'vue';

    const excelStore = useExcelStore()
    const bomData = ref();
    const cadData = ref();

    watch(excelStore.bomRecord , (newValue,oldValue) => {
        if(newValue){
            bomData.value = newValue.data;
        }
    })

    watch(excelStore.cadRecord , (newValue,oldValue) => {
        if(newValue){
            cadData.value = newValue.data;
        }
    })

    onMounted(() => {
        bomData.value = excelStore.bomRecord.data;
        cadData.value = excelStore.cadRecord.data;
    })

    // watch([
    //     () => excelStore.bomRecord.data,
    //     () => excelStore.cadRecord.data
    // ]
    // , ([ 
    //     bomRecordData, cadRecordData 
    // ]) => {
    //     // 如果 bomRecordData 和 cadRecordData 都有值，則更新 bomData 和 cadData
    //     if (bomRecordData || cadRecordData) {
    //         bomData.value = bomRecordData;
    //     }
    //     if(cadRecordData){
    //         cadData.value = cadRecordData;
    //     }
    // });
    
</script>