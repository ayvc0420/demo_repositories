<template>
    <div>
        <label for="bomFileRef">上傳 BOM File : </label>
        <!-- <input type="file" ref="bomFile" @click="" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"> -->
        <input type="file" ref="bomFileRef" id="bomFileRef" @change="uploadBOMFileExcel($event.target.files[0])" accept=".xlsx, .xls">
        <hr>
        <label for="cadFileRef">上傳 CAD File : </label>
        <input type="file" ref="cadFileRef" id="cadFileRef" @change="uploadCADFileExcel($event.target.files[0])" accept=".csv">
    </div>
</template>


<style>
</style>
<script setup>
    import { useExcelStore } from '@/stores/excelStore.js'
    import { ref, onMounted } from 'vue';
    import { handleXLSData, handleXLSXData, handleCSVData } from '@/utlis/excelHelper.js';

    const excelStore = useExcelStore()
    const bomFileRef = ref(null);
    const cadFileRef = ref(null);
    const xlsType = 'application/vnd.ms-excel';
    const xlsxType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    const csvType = 'text/csv';
    

    const uploadBOMFileExcel = async (excelFile) => {
        if(excelFile?.type === xlsType){
            console.time();
            const { rootData } = await handleXLSData(excelFile, excelStore.bomRecord.findKey);
            excelStore.bomRecord.data = rootData;
            console.log('xls : -> ',excelStore.bomRecord);
            console.log('xls處理時間 : ');
            console.timeEnd();
            return;
            // console.log(result);
        }else if(excelFile?.type === xlsxType){
            console.time();
            const { rootData } = await handleXLSXData(excelFile, excelStore.bomRecord.findKey);
            excelStore.bomRecord.data = rootData;
            console.log('xlsx : -> ',excelStore.bomRecord);
            console.log('xlsx處理時間 : ');
            console.timeEnd();
            return;
        }else{
            if(excelFile){
                alert('請選擇 Excel 檔案 (xlsx 或 xls)');
                bomFileRef.value.value = '';
            }
            return;
        }
    }

    const uploadCADFileExcel = async (csvFile) => {
        if(csvFile?.type === csvType){
            console.time();
            const { rootData } = await handleCSVData(csvFile, excelStore.cadRecord.findKey);
            excelStore.cadRecord.data = rootData;
            console.log('csv : -> ',excelStore.cadRecord);
            console.log('csv處理時間 : ');
            console.timeEnd();
        }else{
            if(csvFile){
                alert('請選擇 CSV 檔案');
                cadFileRef.value.value = '';
            }
            return;
        }
        console.time();
    }

    onMounted(() => {
        console.log('load ok');
    })


</script>