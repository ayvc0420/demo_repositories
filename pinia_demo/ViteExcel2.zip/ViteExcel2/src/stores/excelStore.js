import { defineStore } from 'pinia'
import { ref, onMounted } from 'vue';

export const useExcelStore = defineStore('excelStore', () => {
    const bomRecord = ref({});
    const cadRecord = ref({});

    onMounted(() => {
        bomRecord.value.findKey = '編號,類別,描述';
        bomRecord.value.data = [];
        cadRecord.value.findKey = '第一層,第二層,第四層';
        cadRecord.value.data = [];
    })

    
    return {
        bomRecord,
        cadRecord
    }
})