import Papa from 'papaparse';
import ExcelJS from 'exceljs';
import * as XLSX from 'xlsx';

const replaceNullText = '此欄位無資料';

const handleXLSXData = async (xlsxFile,headerKeyStr) => {
    const findKey = headerKeyStr.split(',');
    

    const useRow = true; 
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(xlsxFile);

    const worksheet = workbook.getWorksheet(1);
    const headerData = worksheet.getRow(1).values.map(data => data);
    const setting = findKey.map(key => ({ 
        key, 
        forExcelIndex: headerData.findIndex(data => key === data)
    }));

    if(useRow === true){
        // 每行資料判斷後索取

        const rootData = [];
        const allSettingIndex = setting.map(d => d.forExcelIndex);
        for (let i = 2; i <= worksheet.rowCount; i++) {
            const obj = {};
            worksheet.getRow(i)?.eachCell({ includeEmpty: true }, (cell, colNumber) => {
                if (allSettingIndex.includes(colNumber) === true) {
                    const k = headerData[colNumber];
                    obj[k] = cell.value ? cell.value.toString() : replaceNullText;
                }
            })
            rootData.push(obj);
        }
        //更新 key 對應 data 的 index
        // for(const data of setting){
        //     const ind = rootData[0]?.findIndex(d => d === data.key);
        //     if(ind !== -1){
        //         data.forDataIndex = ind;
        //     }
        // }

        return { rootData };
        // return { setting, rootData };
    }
    // else{
    //     // 用 列 概念抓取資料

    //     const excelDataArray = setting.map((data, index) => {
    //         data.forDataIndex = index;
    //         const arr = [];
    //         worksheet?.eachRow({ includeEmpty: false }, (row, rowNumber) => {
    //             const cellValue = row.getCell(data.forExcelIndex).value;
    //             arr.push(cellValue === undefined || cellValue === null ? replaceNullText : cellValue);
    //         });
    //         return arr;
    //     })
    //     const rootData = excelDataArray[0].slice(1).map((item, index) => {
    //         const obj = {};
    //         // 將資料進行 {}[] 儲存
    //         excelDataArray.forEach((row) => {
    //             if(row[0]){
    //                 obj[row[0]] = row[index + 1] || replaceNullText;
    //             }
    //         });
    //         return obj;
    //     })

    //     return { rootData };
    // }

}

const handleXLSData = async (xlsFile, headerKeyStr) => {
    const findKey = headerKeyStr.split(',');
    

    const useBuiltJson = false;
    const workbook = XLSX.read(await new Response(xlsFile).arrayBuffer());
    const sheet = workbook.Sheets[workbook.SheetNames[0]];  // 第一個工作表
    if(useBuiltJson === true){
        const rootXlsJson = XLSX.utils.sheet_to_json(sheet);  // key = header (A1,B1,C1,D1 ...) , data = body
        // console.log('rootXlsJson',rootXlsJson)
        const rootData = rootXlsJson.map(data => {
            const obj = {};
            for(const [key,value] of Object.entries(data)){
                if(findKey.includes(key) === true){
                    obj[k] = value ? value.toString() : replaceNullText;
                    // obj[key] = value || replaceNullText;
                }
            }
            return obj;
        })
        // .slice(1);  若第二行為特殊用途從第三行開始讀則要 slice

        return { rootData };
    }else{
        const range = XLSX.utils.decode_range(sheet['!ref']);

        const rowIndex = [];
        for (let colNum = range.s.c; colNum <= range.e.c; colNum++) {
            const cellName = XLSX.utils.encode_cell({r: 0, c: colNum});
            const cell = sheet[cellName];
            const cellValue = (cell ? cell.v : replaceNullText);
            if(findKey.includes(cellValue) === true){
                rowIndex.push(colNum);
            }
        }
        const rootData = [];
        // 列 (上到下)  第二行為 Property 的話要從 2 開始 否則從 1
        for (let rowNum = 1; rowNum <= range.e.r; rowNum++) {
            const rowObj = {};
            // 行 (左到右)
            for(const i of rowIndex){
                const cellName = XLSX.utils.encode_cell({r: 0, c: i});
                const cell = sheet[cellName];
                const key = (cell ? cell.v : replaceNullText);
                const cellValue = sheet[XLSX.utils.encode_cell({r: rowNum, c: i})]?.v;
                rowObj[key] = cellValue ? cellValue.toString() : replaceNullText;
            }
            rootData.push(rowObj);
        }

        return { rootData };
    }

}

const handleCSVData = async (csvFile, headerKeyStr) => {
    const findKey = headerKeyStr.split(',');
    

    return new Promise(resolve => {
        Papa.parse(csvFile, {
            header: true,
            // skipEmptyLines: 'greedy',   // 跳過中間空白資料
            skipEmptyLines: true,       // If true, lines that are completely empty (those which evaluate to an empty string) will be skipped. If set to 'greedy', lines that don't have any content (those which have only whitespace after parsing) will also be skipped.
            complete: (results) => {
                const csvData = results.data;
                console.log('csvData',csvData)
                const rootData = csvData.map(data => {
                    const obj = {};
                    findKey.forEach(key => {
                        obj[key] = data[key] || replaceNullText;
                    });
                    return obj;
                });

                resolve({ rootData });
            }
        });
    });
}

export { handleCSVData, handleXLSData, handleXLSXData };