import { defineConfig } from 'vite';
import { resolve } from 'path';
import vue from '@vitejs/plugin-vue';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: {
      '@' : resolve(__dirname, './src')
    }
  },
  build: {
    rollupOptions: {
      // 將 utils 目錄下的所有文件一併包含在構建結果中
      output: {
        dir: resolve(__dirname, './dist'), // 修改為你的構建輸出目錄
        entryFileNames: '[name].js',
        chunkFileNames: '[name].js',
        assetFileNames: '[name][extname]'
      }
    }
  },
  base: './'
})
